# Folse Tech Next.js Site
Production-ready SEO site.