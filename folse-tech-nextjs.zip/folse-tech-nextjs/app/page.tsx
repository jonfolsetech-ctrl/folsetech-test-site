export default function Home() {
  return <h1>Folse Tech – AI Web Design in Gonzales, Louisiana</h1>;
}